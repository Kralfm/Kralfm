# Kral FM Muhabbet

Bu klasördeki `index.html` temel sohbet arayüzüdür.

Not: Bu sürüm tarayıcı içinde örnek mesaj gösterimi yapar. Gerçek zamanlı, çok kullanıcılı sohbet için bir backend/veritabanı bağlantısı eklenmelidir.
